module.exports = {
  dist: ['dist/*'],
  dists:[
    'dist/css/**', 
    'dist/js/*.js', 
    'dist/vendor/angular/', 
    'dist/js/directives', 
    'dist/js/services', 
    'dist/js/filters', 
    'dist/index.min.html'
  ]
};