    <div class="container w-xxl w-auto-xs" ng-controller="SignupFormController" >
      <a href class="navbar-brand block m-t">[:name1:]</a>
      <div class="m-b-lg">
        <div class="wrapper text-center">
          <strong>Signup to jion us</strong>
        </div>
        <form name="form" class="form-validation">
          <div class="text-danger wrapper text-center" ng-show="authError">
              
          </div>
          <div class="list-group list-group-sm">
            <div class="list-group-item">
              <input type="email" placeholder="Email" class="form-control no-border" ng-model="User.signup_data.CEmail" required>
            </div>
            <div class="list-group-item">
               <input type="password" placeholder="Password" class="form-control no-border" ng-model="User.signup_data.CPassword" required>
            </div>
          </div>
          <div class="checkbox m-b-md m-t-none">
            <label class="i-checks">
              <input type="checkbox" ng-model="agree" required><i></i> Agree the <a href>terms and policy</a>
            </label>
          </div>
          <button type="submit" class="btn btn-lg btn-primary btn-block" style=" width:50%; margin:0 80px;" ng-click="User.signup()" ng-disabled='form.$invalid'>Sign up</button>
          <div class="line line-dashed"></div>
          <p class="text-center"><small>Already have an account?</small></p>
          <a ui-sref="login" style=" width:50%; margin:0 80px;" class="btn btn-lg btn-default btn-block">Sign in</a>
        </form>
      </div>
      
    </div>