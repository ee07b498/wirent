 <div class="" style="background: #f2f5f7;">
  <div class="row">
   <!-- carousel -->
      <div ng-controller="CarouselDemoCtrl" class="panel b-a" set-ng-animate="false">
        <carousel interval="myInterval">
          <slide ng-repeat="slide in slides" active="slide.active">
            <img ng-src="[:slide.image:]" class="img-full" style="height: 400px;">
            <div class="carousel-caption">
             <!-- <h4>Slide [:$index:]</h4>
              <p>[:slide.text:]</p>-->
            </div>
          </slide>
        </carousel>
        <!--<div class="panel-footer">
          <button type="button" class="btn btn-default m-r" ng-click="addSlide()">Add Slide</button>
          Interval: <input type="number" class="form-control w-sm inline" ng-model="myInterval"> ms          
        </div>-->
      </div>
      <!-- / carousel -->     
    </div>
    <div class="row container-fluid m-r-n-xs">
    	<div class="col-sm-8">
    		<div class="panel panel-default">
		        <div class="panel-heading">
		        	<div class="row b-b">
		        		<div class="col-sm-8 ">
		        			<div class="m-t-md">
		        				<h3>$585</h3>
		        				<small class="block m-t-xs">9/20 harbourne road, kingsford NSW 2032 </small>
		        			</div>
		        		</div>
		        		<div class="col-sm-4">
		        			 <div class="hbox text-center">          
					              <a href class="col padder-v text-muted b-r b-light">
					                <div class="h4">
					                	<span class="fa-stack fa-lg">
							                <i class="fa fa-circle fa-stack-2x text-white"></i>
							                <i class="fa fa-bed fa-stack-1x "></i>
							            </span>
					                </div>
					                <span>2 Rooms</span>
					              </a>
					              <a href class="col padder-v text-muted b-r b-light">
					                <div class="h4">
					                	<span class="fa-stack fa-lg">
							                <i class="fa fa-circle fa-stack-2x text-white"></i>
							                <i class="fa fa-bath fa-stack-1x "></i>
							            </span>
					                </div>
					                <span>2 Baths</span>
					              </a>
					              <a href class="col padder-v text-muted">
					                <div class="h4">
					                	<span class="fa-stack fa-lg">
							                <i class="fa fa-circle fa-stack-2x text-white"></i>
							                <i class="fa fa-car fa-stack-1x "></i>
							            </span>
					                </div>
					                <span>1 Parking</span>
					              </a>
					          </div>
		        		</div>
		        	</div>
		        	<div class="row">
		        		<div>
		        			<h5 class="inline full-screen m-l-md m-r-xxl">Available from Monday, 8 May 2017</h5>
		        			<span class="b-r"></span>
		        			<h5 class="inline full-screen m-l-xxl">Bond $2540.00</h5>
		        		</div>
		        	</div>
		        </div>
		        <div class="panel-body">
		          <article class="media">
		            <div class="pull-left">
		              <span class="fa-stack fa-lg">
		                <i class="fa fa-circle fa-stack-2x"></i>
		                <i class="fa fa-wikipedia-w fa-stack-1x text-white"></i>
		              </span>
		            </div>
		            <div class="media-body">                        
		              <a href class="h4"> Spacious Two Bedroom Apartment <span class="badge">New</span> </a>
		              	<small class="block m-t-xs">Positioned in a well maintained block is this bright and sunny apartment. Centrally located and only moments to Kingsford local shops, cafes and UNSW, this oversized apartment is a must see. It feautures: </small>
		              	<small class="block m-t-xs">- Two spacious bedrooms</small>
						<small class="block m-t-xs">- L-Shaped lounge and dining</small>
						<small class="block m-t-xs">- Shared laundry</small>
						<small class="block m-t-xs">- Balcony</small>
						<small class="block m-t-xs">- Lock up garage plus storage</small>
		              <em class="text-xs">Available from <span class="text-danger">Monday 8th of May 2017.</span> 6-12 month lease to commence with the option to renew and stay on. </em>
		            </div>
		          </article>
		          <div class="line pull-in"></div>
		          <article class="media">
		            <div class="pull-left">
		              <span class="fa-stack fa-lg">
		                <i class="fa fa-circle fa-stack-2x"></i>
		                <i class="fa fa-wikipedia-w fa-stack-1x text-white"></i>
		              </span>
		            </div>
		            <div class="media-body">
		              <a href class="h4">Property type: <span class="badge">House</span> </a>
		              <small class="block m-t-xs">Disclaimer: While all care has been taken in compiling information regarding properties marketed for rent or sale, we accept no responsibility and disclaim all liabilities in regards to any errors or inaccuracies contained herein. All parties should rely on their own investigation to validate information provided.</small>
		            </div>
		          </article>
		          
		        </div>
		      </div>
    	</div>
    	<!--<div class="col-sm-1"></div>-->
    	<div class="col-sm-4">
    	<div class="col-sm-12">
          <div class="panel b-a">
            <!--<div class="panel-heading bg-info dk no-border wrapper-lg">
              <button class="btn btn-sm btn-icon btn-rounded btn-info pull-right m-r"><i class="fa fa-phone"></i></button>
              <button class="btn btn-sm btn-icon btn-rounded btn-info m-l"><i class="fa fa-heart"></i></button>
            </div>-->
            <div class="text-center m-b clearfix">
              <div class="thumb-lg avatar m-t-n-xxl text-center">
                <img src="img/andy.jpg" alt="..." class="b b-3x b-white">
                <div class="h4 font-thin m-t-sm">Andy Sun</div>
                <div class="h4 font-thin m-t-sm m-l-lg">Winning Investment Pty Ltd</div>
              </div>
            </div>
            <div class="padder-v b-t b-light bg-light lter row text-center no-gutter">
              <div class="col-xs-4">
                <div>Performance</div>
                <div class="inline m-t-sm">
                  <div ui-jq="easyPieChart" ui-options="{
                      percent: 30,
                      lineWidth: 3,
                      scaleColor: false,
                      color: '#fff',
                      size: 65,
                      lineCap: 'butt',
                      rotate: 45,
                      animate: 1000
                    }">
                    <div>
                      <span class="step">80</span>%
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-xs-4">
                <div>age</div>
                <div class="inline m-t-sm">
                  <div ui-jq="easyPieChart" ui-options="{
                      percent: 50,
                      lineWidth: 3,
                      scaleColor: false,
                      color: '#fff',
                      size: 65,
                      lineCap: 'butt',
                      rotate: 90,
                      animate: 1000
                    }">
                    <div>
                      <span class="step">27</span>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-xs-4">
                <div>Working</div>
                <div class="inline m-t-sm">
                  <div ui-jq="easyPieChart" ui-options="{
                      percent: 20,
                      lineWidth: 3,
                      scaleColor: false,
                      color: '#fff',
                      size: 65,
                      lineCap: 'butt',
                      rotate: 180,
                      animate: 1000
                    }">
                    <div>
                      <span class="step">5</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="hbox text-center b-t b-light">          
              <a href class="col padder-v text-muted b-r b-light">
                <div class="h4">
                	<span class="fa-stack fa-lg">
		                <i class="fa fa-circle fa-stack-2x text-info"></i>
		                <i class="fa fa-phone fa-stack-1x text-white"></i>
		            </span>
                </div>
                <span>Call</span>
              </a>
              <a href class="col padder-v text-muted">
                <div class="h4">
                	<span class="fa-stack fa-lg">
		                <i class="fa fa-circle fa-stack-2x text-info"></i>
		                <i class="fa fa-envelope-o fa-stack-1x text-white"></i>
		            </span>
                </div>
                <span>Email</span>
              </a>
            </div>
          </div>
        </div>

    	</div>
    </div>
    <div class="row">
    	<ng-map center="-33.8688197,151.20929550000005" zoom="18">
		    <marker position="sydney australia" title="Hello World!"
		      optimized="false" animation="Animation.BOUNCE"
		      icon="{
		        url:'img/blue.png',
		        scaledSize:[30,30],
		        origin: [0,0],
		        anchor: [10,10]
		      }"></marker>
		 </ng-map>
    </div>
</div>     